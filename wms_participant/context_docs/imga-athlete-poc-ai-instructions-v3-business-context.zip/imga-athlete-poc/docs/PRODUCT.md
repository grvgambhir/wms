# PRODUCT.md

> For the full domain/business explanation, wider GMS context, roles, lifecycle and POC-vs-production boundaries, read `BUSINESS_CONTEXT.md`.

## 1. Product in one sentence
A centralized Masters Games athlete experience where a participant can create an account, register for an event and sport, complete eligibility and payment, receive accreditation, and use a GamesHub for event-time schedule, information, and results.

## 2. Broader system context
The complete IMGA vision is larger than this mobile POC. The broader Games Management System is expected to support athletes, organizers, officials, and volunteers across mobile, web, and desktop, with registration, sport entries, accreditation, communication, payments, reporting, partner/team formation, quotas, document verification, and results.

This repository starts only with the Athlete Mobile POC, while keeping architecture compatible with a future Admin Web application and shared backend.

## 3. Athlete problem being solved
A participant should not need separate disconnected systems for:
- creating an athlete identity
- choosing an event and sport
- submitting registration
- proving eligibility
- finding or inviting a partner
- paying
- tracking approval
- receiving event credentials
- finding schedule/event information
- checking live/final results

The mobile app combines this into one coherent journey.

## 4. Why athlete profile matters
Registration is the main transactional flow, but the athlete profile is the identity layer underneath it.

The profile can eventually support:
- reuse across future Games editions
- pre-filling future registrations
- long-term participation history
- results continuity
- future IMGA community/profile synchronization

For this POC, the profile is local/mock but must be modeled as a first-class domain entity, not as fields trapped inside one registration screen.

## 5. POC audience
Primary:
- athlete / participant

Future system users:
- IMGA administrators
- LOC/event administrators
- sport managers
- accreditation staff
- finance/registration operators
- officials
- volunteers/workforce

## 6. POC success criteria
A viewer should understand the full athlete journey without explanation:
1. athlete enters the app
2. discovers an IMGA event
3. chooses a sport
4. completes registration
5. provides profile and eligibility information
6. uploads documents and accreditation photo
7. handles partner/team selection
8. reviews terms and mock payment
9. sees submitted/approved registration status
10. receives digital accreditation
11. uses GamesHub
12. sees live/final match information

## 7. Production-minded POC principle
The POC must be fast, but not throwaway.

Mock data sources are temporary.
Screen structure, navigation, UI, forms, validation, status modeling, feature boundaries, domain contracts, and reusable components should be production-reusable.

## 8. Out of scope for this athlete POC
- Admin web implementation
- real backend/database
- real OTP/email/SMS
- real payment processing
- real accreditation printer or access-control hardware
- actual venue scoring engine
- real results integration
- full volunteer/workforce module
- accommodation/transport booking integrations
- medical workflow beyond simple declaration/document representation
- production-grade security/compliance implementation
- full localization
