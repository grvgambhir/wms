# IMPLEMENTATION_PLAN.md

## Objective
Get a high-quality Athlete Mobile POC running as fast as possible without creating throwaway UI architecture.

## Phase 0 — Bootstrap
1. Create Expo TypeScript app.
2. Add Expo Router.
3. Add NativeWind.
4. Add TanStack Query.
5. Add React Hook Form + Zod.
6. Add AsyncStorage.
7. Add Expo Image Picker / Document Picker.
8. Configure strict TypeScript.
9. Create folder structure from `ARCHITECTURE.md`.

## Phase 1 — Design foundation
Build:
- theme/tokens
- AppScreen
- header
- buttons
- inputs
- cards
- status badge
- progress stepper
- bottom action bar
- loading/empty/error states

Do not build every possible generic component first.

## Phase 2 — Mock domain/data layer
Create:
- domain models
- repository contracts
- canonical fixture files
- mock repositories
- asset registry
- AsyncStorage wrapper

Seed canonical Daniel/Marco/Como demo data.

## Phase 3 — Auth and discovery
Implement:
- A01 Login
- A02 OTP
- A03 Events
- A04 Event Details
- A05 Choose Sport
- A06 Registration Overview

Validate navigation and visual system here before expanding.

## Phase 4 — Registration core
Implement:
- A07 Profile
- A08 Sport & Category
- A09 Documents
- A10 Photo
- A11 Partner Setup
- A12 Partner Finder

Persist registration draft.

## Phase 5 — Submission
Implement:
- A13 Review + T&C
- A14 Mock Payment
- A15 Registration Status

Create deterministic mock state transitions.

## Phase 6 — Event-time
Implement:
- A16 Digital Accreditation
- A17 GamesHub
- A18 Live Result

Build mock results subscription/provider.

## Phase 7 — Polish
- responsive pass
- loading/error/empty states
- Android/iOS layout pass
- route guards where needed
- demo reset mechanism
- remove dead code
- TypeScript/lint cleanup
- consistency pass against screenshots/mockups

## AI-agent execution rule
Do not ask an agent to build all 18 screens in one giant step.

Recommended Cursor/Claude task sequence:
1. bootstrap + architecture
2. design system
3. mock domain/data layer
4. A01–A06
5. A07–A12
6. A13–A15
7. A16–A18
8. polish/refactor

After each batch:
- run app
- fix navigation
- verify mock data consistency
- check TypeScript


## Iteration strategy
### Default development loop
1. Start Expo with web support.
2. Build/review the current batch in the browser.
3. Fix layout, navigation, mock-state, and TypeScript issues quickly.
4. When the batch is stable, validate on Android.
5. Validate on iOS when available.
6. Fix only cross-platform issues found in the native pass.
7. Continue to the next batch.

Do not wait for APK/IPA/native builds after every UI change.

### Native-feature timing
During POC, prefer mock/simplified interactions for anything that can create native setup delays.

Examples:
- Accreditation photo: a browser-compatible image selection/preview is enough initially; camera-specific polish can come later.
- Payment: mock processing only.
- Digital pass: render the credential and QR; Wallet integration is deferred.
- Live results: mock provider; no native background transport requirements.
