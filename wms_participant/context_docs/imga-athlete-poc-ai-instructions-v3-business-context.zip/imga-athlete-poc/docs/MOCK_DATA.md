# MOCK_DATA.md

## Purpose
Provide one consistent demo universe so every screen tells the same story.

All values below are POC/demo data unless the source documents explicitly confirm them.

## Canonical athlete
```json
{
  "id": "athlete_daniel_harper",
  "firstName": "Daniel",
  "lastName": "Harper",
  "dateOfBirth": "1984-05-14",
  "nationalityCountryCode": "GB",
  "email": "daniel.harper@example.com",
  "phone": "+44 7700 900123"
}
```

## Canonical partner
```json
{
  "id": "athlete_marco_rossi",
  "firstName": "Marco",
  "lastName": "Rossi",
  "dateOfBirth": "1985-02-11",
  "nationalityCountryCode": "IT",
  "email": "marco.rossi@example.com"
}
```

## Canonical event
Use a demo event representing:
- Open Masters Games 2027
- Como, Italy

Recommended ID:
`event_omg_como_2027`

Do not assume exact dates, fee, participant counts, or venue counts are official unless updated from confirmed source material.

## Canonical sport
```json
{
  "id": "sport_tennis",
  "name": "Tennis"
}
```

## Canonical discipline/category
```json
{
  "id": "discipline_tennis_mens_doubles",
  "name": "Men's Doubles",
  "participantType": "doubles"
}
```

```json
{
  "id": "category_tennis_md_40_44",
  "name": "Men's Doubles 40–44",
  "ageGroup": "40–44",
  "entryType": "competitive",
  "partnerRequired": true,
  "quotaStatus": "available"
}
```

## Suggested additional event fixtures
Use 2–4 believable demo events so the Events screen is not empty.
Clearly treat names/dates as mock where not source-confirmed.

## Suggested additional sport fixtures
- Swimming
- Athletics
- Cycling
- Badminton
- Basketball
- Rowing

These help demonstrate filtering and multi-sport structure.

## Partner Finder fixtures
Create 6–10 athletes with:
- stable ID
- name
- country
- age
- compatible sport/category
- optional handedness/experience label
- profile asset key

Do not use fake rating systems unless the UI explicitly needs them.

## Documents
Canonical document types:
- passport / ID proof
- date of birth proof
- medical declaration
- liability waiver

POC verification may be pre-populated or toggled through mock state.

## Payment
Recommended demo:
- currency: EUR
- configurable mock entry fee
- optional service fee
- optional promo code
- deterministic fake payment ID, e.g. `PAY-DEMO-000123`

Avoid embedding the amount in many files.
Keep fee configuration in one mock event/registration config source.

## Registration
Recommended ID:
`REG-DEMO-000124`

Canonical progression:
```text
draft
-> submitted
-> under_review
-> approved
-> accreditation_pending
-> accreditation_issued
```

Support alternate demo states:
- action_required
- waitlisted
- rejected

## Accreditation
Recommended:
- stable mock accreditation ID
- QR encodes mock ID, not private/sensitive data
- access level: Athlete
- event validity dates derive from event fixture

## GamesHub
Suggested sections:
- next match
- today's schedule
- digital pass shortcut
- results
- venues
- medals
- favourites
- announcements
- lightweight weather/info card

## Canonical match
Daniel Harper / Marco Rossi versus a mock opponent pair.

Recommended ID:
`match_tennis_demo_001`

The results provider should progress through a small deterministic sequence.

Example:
```text
scheduled
-> live
-> score update 1
-> score update 2
-> completed
```

The exact tennis score does not need to represent a full scoring engine; it only needs to demonstrate live result publication.
