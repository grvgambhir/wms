# DESIGN_SYSTEM.md

## Design intent
Premium international sports event app.
Modern, clean, energetic, trustworthy.

It should feel consumer-facing and event-focused, not like a back-office form system.

## Core visual principles
- light neutral surfaces
- deep blue primary brand family
- clear visual hierarchy
- restrained event imagery
- rounded cards
- generous spacing
- clear status colors
- strong but simple typography
- compact forms split into logical steps
- large touch targets
- consistent bottom/action areas

## Suggested tokens

### Colors
Use semantic tokens rather than hardcoded colors in components.

```ts
colors = {
  background: "#F7F9FC",
  surface: "#FFFFFF",
  surfaceMuted: "#F1F5F9",
  primary: "#0D47B5",
  primaryDark: "#082E78",
  text: "#0F172A",
  textMuted: "#64748B",
  border: "#E2E8F0",
  success: "#16A34A",
  warning: "#F59E0B",
  danger: "#DC2626",
  info: "#2563EB",
}
```

Exact colors can be refined during implementation, but use centralized tokens.

### Radius
```ts
radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  pill: 999,
}
```

### Spacing
Use a 4pt/8pt-friendly scale.

```ts
spacing = {
  1: 4,
  2: 8,
  3: 12,
  4: 16,
  5: 20,
  6: 24,
  8: 32,
  10: 40,
}
```

## Typography
Prioritize legibility over novelty.

Suggested hierarchy:
- Display / event hero
- H1 screen title
- H2 section title
- Body
- Small/meta
- Button label
- Status label

Use one modern sans-serif family consistently.

## Core reusable components
Build these before or during the first screens:

### Foundation
- `AppScreen`
- `AppHeader`
- `SafeAreaContainer`
- `Section`
- `Divider`
- `BottomActionBar`

### Inputs
- `TextField`
- `SelectField`
- `DateField`
- `OtpInput`
- `CheckboxRow`
- `SearchField`

### Actions
- `PrimaryButton`
- `SecondaryButton`
- `TextButton`
- `IconButton`

### Cards
- `EventCard`
- `SportCard`
- `RegistrationSummaryCard`
- `DocumentCard`
- `PartnerCard`
- `MatchCard`
- `AccreditationCard`
- `InfoCard`

### Status
- `StatusBadge`
- `ProgressStepper`
- `RegistrationTimeline`
- `QuotaBadge`

### Feedback
- `LoadingState`
- `EmptyState`
- `ErrorState`
- `SuccessBanner`
- `ActionRequiredBanner`

## Navigation patterns
Pre-registration:
- back navigation
- screen titles
- registration progress stepper

Event-time:
- bottom navigation or tab structure
- GamesHub as primary home

## Registration UX
Do not show one massive form.

One logical task per screen:
- profile
- entry
- documents
- photo
- partner
- review
- payment

Each screen should:
- explain why the information is needed
- show a clear primary action
- allow safe save/exit if useful
- preserve entered data

## Status language
Use user-friendly states:
- Under Review
- Action Required
- Waitlisted
- Approved
- Accreditation Ready
- Live
- Completed

Avoid internal backend names in UI.

## Accessibility
- minimum comfortable tap targets
- sufficient text contrast
- do not rely only on color for state
- readable type sizes
- support dynamic content without clipping
- avoid dense information at small sizes

## Responsive target
Optimize for common phones first:
- iPhone 15/16 class widths
- typical Android 360–430dp widths

Avoid pixel-perfect assumptions tied to one screenshot size.

## Asset strategy
Keep local POC assets organized:
```text
assets/
  branding/
  events/
  sports/
  athletes/
```

Mock fixture data should use stable asset keys rather than importing images inside screen code.

Example:
```ts
event.heroImageKey = "como2027Hero"
```

Resolve keys through a single asset registry.


## Expo Web preview behavior
The browser preview is a development surface, not a desktop redesign.

When running on Expo Web:
- render the athlete app in a phone-like responsive layout
- preserve mobile spacing/navigation hierarchy
- avoid stretching content edge-to-edge across desktop widths
- use a sensible max-width/container only for preview comfort
- do not introduce web-only desktop navigation for the athlete experience

The source UI must still behave correctly on real phone dimensions.
