# BUSINESS_CONTEXT.md

## Purpose of this document

This file gives AI coding agents the **business/domain context behind the IMGA Games Management System**, not just the screen list or technical architecture.

Read this before making product decisions.

The current repository implements only the **Athlete Mobile POC**, but the athlete experience is one part of a broader multi-event, multi-sport Games Management System (GMS). Understanding that wider system is important so the POC does not evolve into a dead-end implementation.

---

# 1. What IMGA is trying to build

IMGA wants a centralized Games Management System for Masters Events worldwide.

The system is intended to support events that can vary greatly in size:
- roughly 1,000 to 50,000+ participants
- roughly 5 to 40+ sports
- multiple Games/events over time

The key business goals are:

1. **Reduce fragmented event operations**
   - registration, sport entries, payments, accreditation, results and participant information should not live in disconnected systems.

2. **Improve the athlete experience**
   - an athlete should be able to move from account creation and registration into an event-time experience without repeatedly entering the same information.

3. **Improve organizer operations**
   - IMGA and Local Organising Committees (LOCs) need configurable tools to manage participants, sports, approvals, quotas, payments, credentials, reports and event information.

4. **Support multiple Games editions**
   - the architecture should allow data continuity and reuse between future IMGA events rather than starting from zero for every Games edition.

5. **Remain configurable and scalable**
   - different events can have different sports, categories, rules, forms, fees and scale.
   - the system should adapt primarily through configuration rather than rebuilding the software for every event.

---

# 2. Who uses the wider platform

The broader system is not only an athlete app.

Potential user groups include:

- Athletes / participants
- IMGA administrators
- Local Organising Committee (LOC) administrators
- Registration operators
- Accreditation staff
- Sport managers
- Finance/payment operators
- Officials
- Volunteers/workforce
- Media and other accredited stakeholders where relevant

For the current POC, we intentionally focus on the **Athlete Mobile experience first**.

A future Admin Web application will manage the operational side.

---

# 3. Simplified product model

Think of the overall product as three connected layers:

```text
ATHLETE / PARTICIPANT EXPERIENCE
Mobile-oriented experience
Registration + profile + event-time GamesHub
          |
          v
CENTRAL GAMES MANAGEMENT SYSTEM
Event configuration + registrations + sport entries +
payments + accreditation + operations + reporting
          |
          v
RESULTS / EVENT INFORMATION ECOSYSTEM
Schedules + live/final results + medals + venue/event information
```

The complete production solution may expose functionality through mobile, web and desktop-compatible interfaces.

---

# 4. The two main applications in our POC thinking

For our implementation strategy, the system can be understood as two major user-facing products.

## 4.1 Athlete Mobile App

This is the participant-facing experience.

The athlete can eventually:

### Before the Games
- create/validate an account
- maintain an athlete profile
- discover an event
- select a sport
- select discipline/category/age group
- register for the Games
- upload eligibility documents
- upload/crop an accreditation photo
- accept Terms & Conditions
- find/invite a doubles or team partner where applicable
- use promo/special codes where applicable
- make payment
- track registration status
- respond to action-required states
- see waiting-list/approval state

### After approval / during the Games
- access digital accreditation
- see authorized access information
- see personal schedule
- see next competition/match
- view venue information
- receive event announcements/notifications
- view live/final results
- view medal/result information
- use favourites
- access relevant event services/information

The current POC implements the core journey from login through live results.

---

## 4.2 Admin Web App

This is the organizer/control-room side of the platform.

The future Admin Web experience can manage:

### Event configuration
- create/manage events
- event dates and information
- branding
- sports
- disciplines
- competition categories
- age groups
- sport-specific configuration

### Registration configuration
- opening/closing dates
- registration forms
- sport-specific fields
- fees
- Terms & Conditions
- quotas
- waiting lists
- promo codes
- corporate/sponsor codes/workflows

### Participant operations
- search/filter participants
- inspect athlete profile
- inspect sport entries
- review documents
- verify eligibility
- request document re-upload
- approve registration
- reject registration
- waitlist registration
- view payment state
- see participant history/status

### Payments
- monitor paid/pending/failed transactions
- view transaction details
- reporting/export
- future refunds/payment reconciliation as required

### Accreditation
- manage accepted/accredited participants
- role/access privileges
- badge/credential generation
- issue/reissue credentials
- accreditation status

### Schedule/results operations
- monitor schedule/result information
- monitor feeds/integration status
- publish/consume event result data
- generate/report result information

### Reporting and administration
- registration reports
- sport-entry reports
- accreditation reports
- payment reports
- exports
- user/role management
- audit/action logs

The Admin Web application is **not currently being implemented in this repository**, but Athlete-side data models must not make this future product difficult.

---

# 5. Multi-user and role-based administration

The admin side should be thought of as a **multi-user system**, not one universal admin login.

A person may:
- have access to one or multiple events
- have different permissions by event
- have different functional roles

Example conceptual roles:

```text
Super Admin
  -> broad system/event access

Event Admin
  -> manages a specific Games edition

Registration Manager
  -> participant registrations and approvals

Sport Manager
  -> sport entries, categories and sport operations

Accreditation Operator
  -> credentials and access privileges

Finance Operator
  -> payment visibility/workflows

Reporting / Read-only User
  -> dashboards and exports
```

These are useful conceptual roles for architecture and mockups. Exact production role names and permission matrices are not fully defined by the RFP and should remain configurable.

Do not hardcode business logic around these example role names.

---

# 6. Athlete Profile vs Registration

This distinction is very important.

## Athlete Profile

Represents the person.

Example information:
- name
- date of birth
- nationality
- contact details
- profile/accreditation identity information

Long-term, this identity may survive across multiple Games editions.

## Registration

Represents that athlete's participation in **one specific event**.

A registration links:

```text
Athlete
 + Event
 + Sport
 + Discipline/Category
 + Documents
 + Partner/Team if relevant
 + Payment
 + Approval status
 + Accreditation
```

An athlete may have:

```text
ONE Athlete Profile
      |
      +-- Registration: Event A
      |
      +-- Registration: Event B
      |
      +-- Registration: Event C
```

Therefore:

**Never design Athlete Profile as if it exists only inside one registration form.**

This is important for future data continuity and athlete legacy/history.

---

# 7. Main registration lifecycle

At a business level, think of registration as a stateful workflow.

Typical simplified lifecycle:

```text
Draft
  |
Submitted
  |
Under Review
  |----------------------|
  |                      |
Action Required       Waitlisted
  |                      |
Resubmitted              |
  |                      |
Under Review <-----------|
  |
Approved
  |
Accreditation Pending
  |
Accreditation Issued
```

Alternate end state:

```text
Under Review -> Rejected
```

The POC does not need every production edge case, but the data model and UI language should allow these states.

---

# 8. Core IMGA business capabilities

The RFP's core requested capabilities include:

- centralized Games Management System
- registration and sport entries
- accreditation / credentialing
- secure accreditation photo upload and crop
- competition/results management and real-time result publication
- communication tools
- payments and invoicing
- multiple currencies/payment methods
- analytics and customizable reporting
- Partner Finder and team formation
- corporate/sponsor registrations using special codes
- quota management
- waiting lists
- promo codes
- document upload and eligibility verification
- mandatory Terms & Conditions
- OTP-based account validation
- multi-language capability
- multi-event / multi-sport scalability

These are part of the wider product context even when a particular POC screen is mocked.

---

# 9. Recommended / future capabilities

The RFP also describes enhanced capabilities that are useful context but are not all mandatory for the current Athlete POC:

- future IMGA online community integration
- SSO/profile synchronization
- result sharing/ongoing post-Games engagement
- health/medical declarations
- accommodation
- transport/tourism integrations
- athlete participation/result legacy tracking
- volunteer/workforce management
- sustainability/CSR tracking
- data continuity between Games editions

Do not implement these just because they appear here.

They are business context and future extensibility considerations.

---

# 10. GamesHub business concept

GamesHub is the athlete's **event-time command center** after registration/accreditation.

It is not simply another registration screen.

Its job is to answer:

- What do I need to do today?
- When/where do I compete?
- What is my next match/event?
- Where is the venue?
- What is my accreditation/access?
- What are the latest results?
- What changed?
- What event information is relevant to me?

Potential GamesHub content:

- digital accreditation
- access/authorized zones where applicable
- schedule
- live/final results
- venues
- medal standings
- favourites
- announcements/news
- notifications
- weather
- relevant accommodation/arrival/departure information

For the POC, A17 GamesHub deliberately shows only enough of this ecosystem to communicate the concept.

---

# 11. Results: very important boundary

The athlete app is primarily a **consumer of results**.

Do not assume this repository must implement timing/scoring logic for all sports.

A broader results architecture may look like:

```text
Venue / External Results System
           |
           v
Central Results / Integration Layer
           |
      +----+-----+
      |          |
      v          v
Web Results   GamesHub / Athlete App
```

External/venue systems may provide:
- schedules
- entries/start lists
- live data
- results
- records
- medals

For the POC:
- mock this feed
- use deterministic live updates
- keep A18 read-only
- do not create a tennis scoring engine

Later the mock results provider can be replaced by WebSocket/SSE/API integration.

---

# 12. Event configuration mindset

The product must not assume every event is identical.

Different Games may have different:
- sports
- disciplines
- categories
- age groups
- quotas
- registration dates
- fees
- required documents
- forms
- languages
- branding
- accreditation rules

Therefore, when possible:

Prefer:

```text
configuration-driven data
```

instead of:

```text
if event === "Como" then ...
```

The POC may have one canonical demo event, but code should not make that event a permanent architectural assumption.

---

# 13. Why local mock data is acceptable for this POC

The current objective is to validate:
- product flow
- UX
- visual direction
- feature organization
- architecture
- stakeholder understanding

We do **not** need a production backend to prove this.

Current POC approach:

```text
Screen
  -> Feature Hook
  -> Repository Contract
  -> Mock Repository
  -> Local JSON / AsyncStorage
```

Future:

```text
Screen
  -> Same Feature Hook
  -> Same Repository Contract
  -> API Repository
  -> Backend
  -> Database
```

The local JSON is temporary.
The product/domain structure should not be temporary.

---

# 14. Current Athlete POC screen flow

The current P1 flow contains 18 screens:

```text
A01 Login / Sign Up
 -> A02 OTP Verification
 -> A03 Events
 -> A04 Event Details
 -> A05 Choose Sport
 -> A06 Registration Overview
 -> A07 Personal Profile
 -> A08 Sport & Category
 -> A09 Eligibility & Documents
 -> A10 Accreditation Photo
 -> A11 Partner / Team Setup
 -> A12 Partner Finder
 -> A13 Review Registration + T&C
 -> A14 Payment
 -> A15 Registration Status
 -> A16 Digital Accreditation
 -> A17 GamesHub Home
 -> A18 Live Match / Result
```

This is the **POC's main end-to-end story**, not a claim that the final production application will contain only 18 screens.

---

# 15. POC demo story

Use one consistent story to make the product easy to understand.

Canonical demo:

```text
Daniel Harper
  |
opens Open Masters Games 2027 demo event
  |
selects Tennis
  |
selects Men's Doubles 40–44
  |
completes profile
  |
submits eligibility documents + photo
  |
finds/selects Marco Rossi
  |
reviews T&C
  |
completes mock payment
  |
registration submitted
  |
registration approved
  |
digital accreditation issued
  |
opens GamesHub
  |
opens next/live tennis match
```

This demonstrates the connection between pre-Games registration and event-time experience.

All names, exact dates, fees, counts, scores and similar detailed demo values are mock unless explicitly confirmed by source material.

---

# 16. Source-of-truth distinction

There are two different source documents behind our understanding.

## IMGA RFP
Treat this as the primary business requirement source.

It describes what IMGA wants from a technology provider.

## Bornan proposal
Treat this as a **reference solution / implementation interpretation**, not as IMGA's requirement word-for-word.

It helps us understand:
- how a mature GMS can be modularized
- accreditation workflows
- sport entries
- multi-user/event permissions
- GamesHub
- central results architecture
- additional operational modules

Do not blindly copy Bornan-specific implementation or branding.

If the proposal and RFP differ, prioritize the IMGA RFP for product requirement intent.

---

# 17. Important POC vs production distinction

## POC
We optimize for:
- speed
- clear demo
- browser-first Expo development
- local/mock data
- reusable design and architecture

## Production
Will eventually require deeper work on:
- real identity/authentication
- backend/database
- payments
- secure file storage
- permissions/RBAC
- auditability
- data protection/security
- localization
- production reporting
- result integrations
- operational support
- scalability
- data migration/continuity

Do not prematurely implement production infrastructure in this POC.

At the same time, do not create UI architecture that makes these production capabilities impossible to add.

---

# 18. Decision rule for AI agents

When unsure whether to implement something, ask:

1. Is it required to demonstrate the documented Athlete P1 flow?
2. Is it explicitly part of the POC scope?
3. Can it be mocked without weakening the demo?
4. Will the chosen structure allow a real backend/provider later?
5. Is this a business requirement or merely a Bornan-specific implementation example?

If the answer is unclear, preserve the simpler extensible design and do not invent major functionality.

---

# 19. One-sentence explanation for stakeholders

> The IMGA platform is a centralized, reusable Games Management ecosystem where athletes can register, pay, receive credentials and use event-time information/results, while organizers manage events, sports, participants, approvals, payments, accreditation, results and reporting through role-based operational tools.

For this repository, we are proving the **Athlete Mobile half first**.
