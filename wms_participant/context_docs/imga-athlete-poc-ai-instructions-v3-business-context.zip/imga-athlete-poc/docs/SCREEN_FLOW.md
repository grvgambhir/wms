# SCREEN_FLOW.md

## Athlete Mobile P1
Total: 18 primary screens.

The IDs below are the canonical design/product references.

---

## A01 — Login / Sign Up
Purpose:
- entry point for returning/new athletes
- collect email or mobile identifier
- initiate account validation

Primary action:
- Continue → A02

POC behavior:
- functional form
- mocked authentication backend

---

## A02 — OTP Verification
Purpose:
- validate athlete account

Primary action:
- Verify → A03

POC behavior:
- canonical OTP `123456`
- resend can be simulated

---

## A03 — Events
Purpose:
- discover available/upcoming Masters Games
- distinguish featured and registered events

Primary action:
- select canonical event → A04

POC behavior:
- loaded from events repository

---

## A04 — Event Details
Purpose:
- explain event before registration
- surface location, dates, sports, registration information and CTA

Primary action:
- Explore Sports → A05

---

## A05 — Choose Sport
Purpose:
- browse/search sports
- show availability/quota-style status

Primary action:
- choose Tennis → A06

POC canonical sport:
- Tennis

---

## A06 — Registration Overview
Purpose:
- explain the registration journey before beginning
- summarize selected event, sport, fee placeholder, inclusions and steps

Primary action:
- Start Registration → A07

---

## A07 — Personal Profile
Purpose:
- create/update athlete identity and contact information

Typical POC fields:
- first name
- last name
- DOB
- gender/category field where relevant
- nationality
- passport/ID reference if desired
- email
- phone
- emergency contact

Primary action:
- Continue → A08

Important:
Profile is a first-class athlete entity and should not exist only inside the registration object.

---

## A08 — Sport & Category
Purpose:
- choose sport discipline and competition category

Canonical demo:
- Tennis
- Men's Doubles
- Age 40–44
- Competitive

Primary action:
- Continue → A09

---

## A09 — Eligibility & Documents
Purpose:
- show eligibility result
- collect required documents

POC examples:
- passport/ID proof
- date-of-birth proof
- medical declaration
- liability waiver

Primary action:
- Continue → A10

POC behavior:
- real device document selection may be used
- verification is mocked

---

## A10 — Accreditation Photo
Purpose:
- collect badge-ready athlete photo

Capabilities:
- camera/gallery
- preview
- crop/position-like experience
- basic photo guidance

Primary action:
- Use Photo → A11

---

## A11 — Partner / Team Setup
Purpose:
- support doubles/team formation

Options:
- I have a partner
- Invite a partner
- Find a partner

Canonical path:
- Find a partner → A12

---

## A12 — Partner Finder
Purpose:
- search/filter athletes who can partner for the selected entry

Canonical demo:
- Marco Rossi

Actions:
- Search/filter
- Send Request / select partner
- Continue → A13

POC behavior:
- repository-backed mock athlete list
- request state stored locally

---

## A13 — Review Registration + T&C
Purpose:
- final review before payment
- confirm profile, sport/category, partner, documents and fees
- mandatory Terms & Conditions acceptance

Primary action:
- Proceed to Payment → A14

---

## A14 — Payment
Purpose:
- demonstrate payment workflow

POC behavior:
- mock methods such as card / Apple Pay / Google Pay / PayPal may be displayed
- promo code can be simulated
- no real gateway

Primary action:
- Pay → A15

---

## A15 — Registration Status
Purpose:
- show lifecycle after submission

Supported states:
- Draft
- Submitted
- Under Review
- Action Required
- Waitlisted
- Rejected
- Approved
- Accreditation Pending
- Accreditation Issued

Canonical demo path:
- Submitted/Under Review → Approved

Primary action after approval:
- View Digital Accreditation → A16

---

## A16 — Digital Accreditation
Purpose:
- provide athlete credential/pass for the event

Display:
- athlete photo
- athlete name
- sport/category
- participant/accreditation ID
- QR code
- access level
- valid dates

Primary action:
- Go to GamesHub → A17

POC:
- QR may encode a mock stable ID
- no physical access-control integration

---

## A17 — GamesHub Home
Purpose:
- become the athlete's event-time home screen

High-value content:
- greeting
- next match
- today's schedule
- digital pass shortcut
- results
- venues
- medals
- favourites
- announcements
- lightweight weather/info card

Primary demo action:
- View Match → A18

Important:
This is the hero event-time screen.

---

## A18 — Live Match / Result
Purpose:
- demonstrate real-time/final result consumption

Display:
- match status
- court/venue
- teams/athletes
- score
- set details
- optional match stats
- last update

POC:
- read-only mock live feed
- no scoring controls
- no scoring engine

---

## Main POC path
```text
A01 Login
 -> A02 OTP
 -> A03 Events
 -> A04 Event Details
 -> A05 Choose Sport
 -> A06 Registration Overview
 -> A07 Personal Profile
 -> A08 Sport & Category
 -> A09 Eligibility & Documents
 -> A10 Accreditation Photo
 -> A11 Partner / Team Setup
 -> A12 Partner Finder
 -> A13 Review + T&C
 -> A14 Payment
 -> A15 Registration Status
 -> A16 Digital Accreditation
 -> A17 GamesHub
 -> A18 Live Match / Result
```
