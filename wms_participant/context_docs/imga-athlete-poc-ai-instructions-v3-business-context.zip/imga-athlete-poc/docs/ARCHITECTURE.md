# ARCHITECTURE.md

## 1. Recommended stack
- React Native
- Expo
- TypeScript
- Expo Router
- NativeWind
- TanStack Query
- React Hook Form
- Zod
- AsyncStorage
- Expo Image Picker
- Expo Document Picker
- Reanimated only where motion materially improves the experience

## 2. Core rule
The UI must never depend directly on the mock-data implementation.

Use:

`UI -> hook/use-case -> repository contract -> implementation`

Current implementation:
`repository contract -> mock JSON / AsyncStorage`

Future implementation:
`repository contract -> real API -> backend -> database`

## 3. Suggested source structure

```text
src/
  app/
    (auth)/
    (registration)/
    (main)/
  components/
    ui/
    event/
    registration/
    athlete/
    accreditation/
    results/
  features/
    auth/
    events/
    registration/
    partners/
    payment/
    accreditation/
    results/
  domain/
    models/
    repositories/
  data/
    mock/
      fixtures/
      repositories/
    storage/
    api/
  hooks/
  services/
  theme/
  utils/
  constants/
assets/
  branding/
  events/
  sports/
  athletes/
docs/
```

If Expo Router is kept under `/app` at repository root instead of `src/app`, preserve the same logical grouping.

## 4. Repository contracts
Expected repositories/services:

```ts
interface AuthRepository {
  requestOtp(identifier: string): Promise<void>;
  verifyOtp(identifier: string, code: string): Promise<AuthSession>;
}

interface EventsRepository {
  listEvents(): Promise<Event[]>;
  getEvent(id: string): Promise<Event | null>;
  listSports(eventId: string): Promise<Sport[]>;
}

interface AthleteRepository {
  getCurrentProfile(): Promise<AthleteProfile | null>;
  saveProfile(input: AthleteProfileInput): Promise<AthleteProfile>;
}

interface RegistrationRepository {
  getDraft(eventId: string): Promise<RegistrationDraft | null>;
  saveDraft(draft: RegistrationDraft): Promise<void>;
  submitRegistration(draft: RegistrationDraft): Promise<Registration>;
  getRegistration(id: string): Promise<Registration | null>;
}

interface PartnerRepository {
  searchPartners(filters: PartnerFilters): Promise<AthleteSummary[]>;
  sendPartnerRequest(targetAthleteId: string): Promise<PartnerRequest>;
}

interface PaymentRepository {
  processMockPayment(input: PaymentInput): Promise<PaymentResult>;
}

interface AccreditationRepository {
  getAccreditation(registrationId: string): Promise<Accreditation | null>;
}

interface ResultsRepository {
  getMatch(matchId: string): Promise<MatchResult | null>;
  subscribeToMatch?(
    matchId: string,
    onUpdate: (result: MatchResult) => void
  ): () => void;
}
```

Exact names may change, but the boundaries should remain.

## 5. State strategy
Use TanStack Query for repository-backed reads and invalidation.

Use React Hook Form for editable forms.

Use local component state only for ephemeral UI state.

Use AsyncStorage for:
- mock auth session
- in-progress registration draft
- small POC state that must survive app restart

Do not use AsyncStorage as a pretend production database.

## 6. Navigation
Logical groups:

```text
(auth)
  login
  otp

(discovery/main)
  events
  event/[id]
  event/[id]/sports

(registration)
  overview
  profile
  category
  documents
  photo
  partner
  partner-finder
  review
  payment
  status

(main)
  accreditation
  gameshub
  match/[id]
```

Preserve the documented A01–A18 experience even if route file names differ.

## 7. Forms
Use React Hook Form + Zod.

Validation belongs in feature/domain schemas, not embedded as random screen conditions.

Examples:
- required profile fields
- date of birth format
- category selection
- T&C acceptance
- required document completion
- partner requirement for doubles

## 8. Mock-to-production migration
POC:
```text
Screen
 -> useEvents()
 -> EventsRepository
 -> MockEventsRepository
 -> events.json
```

Production:
```text
Screen
 -> useEvents()
 -> EventsRepository
 -> ApiEventsRepository
 -> /events API
```

The screen should not change.

## 9. Auth
POC:
- any valid-looking email/mobile may request OTP
- canonical demo OTP: `123456`
- session persisted locally

Production replacement:
- real auth provider or backend OTP

Do not design UI around the fact that OTP is mocked.

## 10. Payment
POC:
- fully designed checkout UI
- simulated processing delay
- deterministic success by default
- optional demo failure state
- generated mock payment/receipt ID

Production replacement:
- real payment gateway behind the same service/repository boundary

## 11. Documents and photos
POC:
- use Expo Document Picker and Image Picker
- save local file URI + metadata
- display upload/verified-like demo states as defined by the POC

Production:
- upload to backend/object storage
- receive remote URL/status

## 12. Results
Do not implement a scoring engine.

POC:
- local result fixture
- timed or scripted updates through a mock results provider

Production:
- WebSocket/SSE/polling integration with external/central result systems

## 13. Future Admin compatibility
When the Admin Web POC is added, both clients should target compatible entities and statuses.

Eventually:
```text
Athlete Mobile
      \
       Shared API
      /
Admin Web
```

Do not create athlete-specific data structures that make admin workflows impossible later.


## POC platform strategy: web-first iteration, mobile-first codebase
The Athlete POC should be implemented as **React Native with Expo**, but the primary development/review environment should initially be **Expo Web**.

Why:
- browser refresh/iteration is faster for AI-agent-driven UI work
- reviewers can validate flows without waiting for native builds
- we preserve one React Native codebase for future Android/iOS
- the POC UI does not need to be rewritten when moving to native

Target flow:

```text
React Native + Expo source
        |
        +--> Expo Web: primary POC iteration/review
        |
        +--> Android: batch compatibility validation
        |
        +--> iOS: batch compatibility validation
```

Do not create a separate React/Vite web implementation.

### Native-only capabilities during POC
Prefer simplified/mock behavior for:
- camera capture
- wallet integration
- push notifications
- real payment sheets
- biometrics
- deep links
- QR scanning
- background services

Use real native APIs only when they are cheap, stable, cross-platform enough, and materially improve the demo.

### Compatibility rule
Every screen must remain capable of running on Android/iOS from the same Expo project.

Avoid:
- DOM elements in feature UI
- `window` / `document` dependencies in screen logic
- CSS-only web implementations that cannot map to React Native
- web-only component libraries for core screens
