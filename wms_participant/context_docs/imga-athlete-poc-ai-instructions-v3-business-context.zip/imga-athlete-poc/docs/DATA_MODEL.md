# DATA_MODEL.md

## Goal
Define stable POC entities that can later map cleanly to backend/database models.

Use string IDs for all relations.

## Event
```ts
type EventStatus = "draft" | "registration_open" | "registration_closed" | "live" | "completed";

interface Event {
  id: string;
  name: string;
  shortName?: string;
  city: string;
  country: string;
  countryCode: string;
  startDate: string;
  endDate: string;
  registrationDeadline?: string;
  status: EventStatus;
  heroImageKey?: string;
  logoKey?: string;
  sportIds: string[];
}
```

## Sport
```ts
interface Sport {
  id: string;
  name: string;
  iconKey?: string;
  eventId: string;
  disciplineIds: string[];
  availability: "available" | "almost_full" | "full" | "closed";
}
```

## Discipline
```ts
interface Discipline {
  id: string;
  sportId: string;
  name: string;
  participantType: "individual" | "doubles" | "team";
  categoryIds: string[];
}
```

## CompetitionCategory
```ts
interface CompetitionCategory {
  id: string;
  disciplineId: string;
  name: string;
  ageGroup: string;
  division?: string;
  entryType?: "competitive" | "recreational";
  partnerRequired?: boolean;
  quotaStatus?: "available" | "almost_full" | "full" | "waitlist";
}
```

## AthleteProfile
```ts
interface AthleteProfile {
  id: string;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  nationalityCountryCode: string;
  gender?: string;
  email: string;
  phone?: string;
  passportNumber?: string;
  emergencyContact?: {
    name: string;
    relationship?: string;
    phone: string;
  };
  profileImageUri?: string;
}
```

## RegistrationDraft
```ts
interface RegistrationDraft {
  id: string;
  athleteId: string;
  eventId: string;
  sportId?: string;
  disciplineId?: string;
  categoryId?: string;
  partnerAthleteId?: string;
  documentIds: string[];
  accreditationPhotoUri?: string;
  termsAccepted: boolean;
  promoCode?: string;
  currentStep: number;
  updatedAt: string;
}
```

## Registration
```ts
type RegistrationStatus =
  | "draft"
  | "submitted"
  | "under_review"
  | "action_required"
  | "waitlisted"
  | "rejected"
  | "approved"
  | "accreditation_pending"
  | "accreditation_issued";

interface Registration {
  id: string;
  athleteId: string;
  eventId: string;
  sportId: string;
  disciplineId: string;
  categoryId: string;
  partnerAthleteId?: string;
  documentIds: string[];
  paymentId?: string;
  status: RegistrationStatus;
  submittedAt?: string;
  approvedAt?: string;
}
```

## EligibilityDocument
```ts
type DocumentStatus = "missing" | "uploaded" | "verified" | "rejected";

interface EligibilityDocument {
  id: string;
  athleteId: string;
  registrationDraftId?: string;
  type: "passport_id" | "dob_proof" | "medical_declaration" | "liability_waiver" | "other";
  fileName: string;
  localUri?: string;
  remoteUrl?: string;
  status: DocumentStatus;
  uploadedAt?: string;
  rejectionReason?: string;
}
```

## PartnerRequest
```ts
type PartnerRequestStatus = "pending" | "accepted" | "declined" | "cancelled";

interface PartnerRequest {
  id: string;
  eventId: string;
  categoryId: string;
  fromAthleteId: string;
  toAthleteId: string;
  status: PartnerRequestStatus;
  createdAt: string;
}
```

## Payment
```ts
type PaymentStatus = "pending" | "processing" | "paid" | "failed" | "refunded";

interface Payment {
  id: string;
  registrationId?: string;
  amount: number;
  currency: string;
  promoCode?: string;
  discountAmount?: number;
  status: PaymentStatus;
  method: string;
  createdAt: string;
}
```

## Accreditation
```ts
interface Accreditation {
  id: string;
  registrationId: string;
  athleteId: string;
  eventId: string;
  badgeNumber: string;
  qrValue: string;
  accessLevel: string;
  validFrom: string;
  validUntil: string;
  status: "pending" | "issued" | "disabled";
}
```

## Venue
```ts
interface Venue {
  id: string;
  eventId: string;
  name: string;
  city: string;
  address?: string;
}
```

## ScheduleItem
```ts
interface ScheduleItem {
  id: string;
  eventId: string;
  athleteId?: string;
  sportId?: string;
  type: "match" | "training" | "ceremony" | "social" | "other";
  title: string;
  startAt: string;
  endAt?: string;
  venueId?: string;
  court?: string;
  matchId?: string;
}
```

## MatchResult
```ts
interface MatchSide {
  id: string;
  displayName: string;
  athleteIds: string[];
  countryCodes?: string[];
}

interface MatchResult {
  id: string;
  eventId: string;
  sportId: string;
  categoryId: string;
  venueId?: string;
  court?: string;
  status: "scheduled" | "live" | "completed";
  sideA: MatchSide;
  sideB: MatchSide;
  scoreSummary: string;
  sets?: Array<{
    label: string;
    a: number | string;
    b: number | string;
  }>;
  updatedAt: string;
}
```

## Notification
```ts
interface AppNotification {
  id: string;
  athleteId?: string;
  eventId: string;
  title: string;
  body: string;
  type: "info" | "schedule_change" | "registration" | "result" | "alert";
  createdAt: string;
  read: boolean;
}
```
