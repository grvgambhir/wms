# POC_SCOPE.md

## Goal
Build the Athlete Mobile P1 experience as quickly as possible while preserving production-reusable structure.

## P1 screen count
18 screens, A01–A18, as defined in `SCREEN_FLOW.md`.

## Functional vs mocked matrix

| Screen | POC level | Notes |
|---|---|---|
| A01 Login / Sign Up | Functional UI + mock service | validate input and request fake OTP |
| A02 OTP | Functional UI + mock service | `123456` succeeds |
| A03 Events | Functional | repository-backed local fixtures |
| A04 Event Details | Functional navigation | repository-backed |
| A05 Choose Sport | Functional | local search/filter may work |
| A06 Registration Overview | Functional navigation | uses selected event/sport |
| A07 Personal Profile | Functional | form + Zod + local persistence |
| A08 Sport & Category | Functional | selection stored in draft |
| A09 Eligibility & Documents | Functional POC | picker works; verification mocked |
| A10 Accreditation Photo | Functional POC | image picker/camera + preview |
| A11 Partner / Team Setup | Functional | choose path |
| A12 Partner Finder | Functional POC | local search + request state |
| A13 Review + T&C | Functional | derived registration summary + required T&C |
| A14 Payment | Mocked interaction | fake delay/success + optional promo |
| A15 Registration Status | Functional state display | local state progression |
| A16 Digital Accreditation | Generated/mock | stable mock QR and badge data |
| A17 GamesHub | Functional dashboard | local/mock event-time data |
| A18 Live Result | Mock realtime | scripted updates; read-only |

## POC data
Use local fixtures and repositories.

No production DB.

Use AsyncStorage only for:
- auth session
- registration draft
- partner request
- mock registration/payment/status data if needed

## Canonical demo journey
Daniel Harper:
- logs in
- verifies OTP
- opens Open Masters Games 2027 demo event
- selects Tennis
- selects Men's Doubles, 40–44
- completes profile
- supplies mock eligibility documents
- selects accreditation photo
- finds Marco Rossi as partner
- reviews T&C
- completes mock payment
- sees registration under review/approved
- receives digital accreditation
- opens GamesHub
- opens live match/result

## Important demo-data disclaimer
Exact event dates, fees, counts, ratings, participant totals, venues, match scores, and names used in the POC are demo content unless explicitly provided by IMGA source material.

Do not present mock values as official facts.

## No backend yet
Do not add:
- PostgreSQL
- Firebase
- Supabase
- custom Node backend
- real authentication service
- real payment gateway

unless explicitly requested.

## When backend becomes useful
Introduce a small shared API only when Athlete Mobile and Admin Web need to mutate/read the same demo state, for example:
- admin approves Daniel
- athlete immediately sees Approved
- admin issues accreditation
- athlete sees credential

Until then, local repositories are faster.

## Live results
Do not build scoring.

Provide a mock results provider that updates the consumer UI over time.

Future production replacement can be WebSocket/SSE/polling from a central/external results service.

## Production reuse target
The following should survive the POC:
- navigation
- UI components
- theme
- forms
- schemas
- feature structure
- domain models
- repository contracts
- hooks
- user-facing state model

The following are expected to change:
- data repository implementations
- storage
- auth
- payment
- document upload transport
- results transport


## POC delivery mode
The fastest delivery path is **Expo Web-first development**.

For P1:
- build/review screens in the browser through Expo Web
- keep all feature code React Native compatible
- mock native-only behavior when it would slow the POC
- run Android/iOS validation after each major batch and before the final demo

This is not a separate web POC. It is the same Expo React Native app being previewed through the browser for speed.
