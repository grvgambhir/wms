# AGENTS.md

## Project
IMGA Athlete Mobile POC — a fast, polished proof of concept for the athlete-facing side of a broader Games Management System for IMGA Masters Events.

The product intent is to demonstrate a complete athlete journey:
account validation → event discovery → sport registration → profile/details → eligibility/documents → accreditation photo → partner/team flow → review/T&C → mock payment → registration status → digital accreditation → GamesHub → live results.

The app is a POC, but it must be structured so that most UI, navigation, validation, state handling, domain types, components, and feature structure can be reused when a real backend is added.

## Source-of-truth priority
When requirements conflict, follow this order:
1. `docs/BUSINESS_CONTEXT.md`
2. `docs/POC_SCOPE.md`
3. `docs/SCREEN_FLOW.md`
4. `docs/PRODUCT.md`
5. `docs/ARCHITECTURE.md`
6. `docs/DATA_MODEL.md`
7. `docs/DESIGN_SYSTEM.md`
8. `docs/MOCK_DATA.md`

Do not invent major product flows outside these files without explicit approval.

Before making product/domain decisions, read `docs/BUSINESS_CONTEXT.md` so implementation choices reflect the wider IMGA GMS business model, not only the current 18-screen POC.

## Mandatory technical rules
- React Native with Expo.
- TypeScript strict mode.
- Expo Router for navigation.
- NativeWind for styling.
- TanStack Query for data fetching/caching abstraction.
- React Hook Form + Zod for forms/validation.
- AsyncStorage only for temporary local persistence.
- Keep mock data behind repository/service interfaces.
- Screens and presentational components must never import JSON fixtures directly.
- No direct storage access from UI components.
- No direct API calls from UI components.
- Avoid `any`; use explicit domain types.
- Reusable UI components and centralized design tokens are mandatory.
- Prefer feature folders and domain boundaries over giant shared utility files.
- All loading, empty, error, disabled, success, pending, rejected, waitlisted, and approved states should be modeled deliberately where relevant.
- Keep user-facing text centralized where practical so localization can be added later.
- POC data may be local/mock, but IDs and entity relationships must be realistic and stable.

## Architecture principle
UI must not care whether data comes from JSON, AsyncStorage, a mock server, REST, GraphQL, or WebSockets.

Expected dependency flow:

`Screen -> feature hook/use-case -> repository interface -> mock repository now / API repository later`

Example:

`EventsScreen -> useEvents() -> EventsRepository -> MockEventsRepository -> events.json`

Later, replace only the repository implementation with `ApiEventsRepository`.

## POC rules
- Prefer speed and clarity over premature infrastructure.
- Do not build a real backend yet.
- Do not integrate a real OTP provider.
- Do not integrate a real payment gateway.
- Do not build a scoring engine.
- Documents and photos may use local device URIs in the POC.
- Live results should be simulated through a mock results provider.
- Use deterministic mock data so demos are repeatable.

## Reusability expectations
Reusable later:
- screen composition
- navigation
- design system
- forms
- validation
- domain types
- repositories/contracts
- hooks
- state transitions
- status components
- empty/loading/error states

Expected to be replaced later:
- auth provider
- payment implementation
- document upload storage
- mock repositories
- result provider
- AsyncStorage persistence

## Code quality
- Keep files focused.
- Prefer composition over prop-heavy mega-components.
- Do not duplicate UI patterns across screens.
- Extract components only when reuse or clarity justifies it.
- Write small typed helpers.
- Keep business rules outside presentational components.
- Use stable IDs instead of display names as relations.
- Add comments only for non-obvious decisions.
- Avoid speculative abstractions with no current use.

## Demo identity consistency
Use the canonical demo entities from `docs/MOCK_DATA.md`.
Do not rename Daniel Harper, Marco Rossi, or the canonical event in one screen without updating the source mock data.

## Visual intent
Athlete experience should feel like a premium international sports event app, not an enterprise admin portal.
Use:
- clean light surfaces
- IMGA-style deep blue as primary brand family
- bold but restrained sports imagery
- rounded cards
- strong hierarchy
- status chips
- clear progress
- large tap targets
- minimal clutter

Do not:
- make every screen gradient-heavy
- use excessive glow effects
- expose technical/debug wording to athletes
- turn long registration steps into one giant form

## Before implementing a screen
1. Read its purpose in `docs/SCREEN_FLOW.md`.
2. Check required data in `docs/DATA_MODEL.md`.
3. Reuse design primitives from `docs/DESIGN_SYSTEM.md`.
4. Confirm whether the interaction is functional, mocked, or static in `docs/POC_SCOPE.md`.
5. Use repository/service abstractions for all external or persisted data.

## Definition of done for a P1 screen
- visually consistent with the design system
- correct navigation
- uses canonical mock data
- supports primary interaction
- handles relevant state(s)
- no direct JSON import in the screen
- no broken TypeScript
- works on common iPhone and Android phone sizes
- no unnecessary production integrations


## POC development mode: Expo Web first
For the fastest POC iteration cycle, develop and review the app primarily through **Expo Web in the browser first**, while keeping the codebase React Native compatible.

The intent is:
`Expo React Native codebase -> fast browser iteration now -> Android/iOS validation later -> same codebase for production mobile`

Rules:
- Prefer cross-platform React Native components that work on Expo Web, Android, and iOS.
- Do not use DOM-only React components or browser-only APIs inside feature screens.
- Do not rewrite screens as a separate React/Vite web app.
- During the POC, avoid native-only implementation work unless it is necessary to prove the flow.
- Camera, wallet, push notifications, native payment sheets, biometrics, deep links, and similar native integrations may be represented by mocked or simplified POC behavior first.
- Use Expo Web as the default feedback loop for screen building and visual review.
- After each major batch is stable on web, perform a focused Android/iOS compatibility pass.
- If a package works on native but poorly on Expo Web, prefer a simpler cross-platform alternative for the POC unless the native behavior is essential.
- Do not sacrifice future mobile compatibility just to make the web preview easier.
