# Cursor Kickoff Prompt

You are implementing the Athlete Mobile POC for an IMGA Masters Games platform.

Before writing code, read these files completely:
- `AGENTS.md`
- `CLAUDE.md`
- `docs/BUSINESS_CONTEXT.md`
- `docs/PRODUCT.md`
- `docs/POC_SCOPE.md`
- `docs/SCREEN_FLOW.md`
- `docs/ARCHITECTURE.md`
- `docs/DATA_MODEL.md`
- `docs/DESIGN_SYSTEM.md`
- `docs/MOCK_DATA.md`
- `docs/IMPLEMENTATION_PLAN.md`

## Product intention
This is not a throwaway static demo.

We need the fastest possible POC of the athlete mobile experience, using local/mock data now, while keeping the screen structure, navigation, forms, design system, domain models, repository contracts, hooks, and component architecture reusable when a production backend is introduced later.

The athlete journey we need to prove is:

Login → OTP → Events → Event Details → Choose Sport → Registration Overview → Personal Profile → Sport & Category → Eligibility & Documents → Accreditation Photo → Partner/Team Setup → Partner Finder → Review + T&C → Mock Payment → Registration Status → Digital Accreditation → GamesHub → Live Match/Result.

Registration is a major flow, but Athlete Profile must be treated as a first-class reusable identity entity because it can later support data continuity across Games editions.

## Technical direction
Use:
- React Native
- Expo
- TypeScript strict mode
- Expo Router
- NativeWind
- TanStack Query
- React Hook Form
- Zod
- AsyncStorage
- Expo Image Picker
- Expo Document Picker

Do NOT create a backend yet.
Do NOT integrate real SMS/email OTP.
Do NOT integrate a real payment gateway.
Do NOT build a scoring engine.
Do NOT hardcode mock JSON inside screens.

All mock data must be hidden behind typed repository/service interfaces so future production migration changes data implementations instead of screen code.

Required flow:

`Screen -> feature hook/use-case -> repository interface -> mock repository`

Later:

`Screen -> same hook/use-case -> same repository interface -> API repository`

## Mocking
Use local fixtures for events, sports, categories, athletes, registrations, schedules, venues, notifications, and results.

Use the canonical Daniel Harper / Marco Rossi / Open Masters Games 2027 demo universe from `docs/MOCK_DATA.md`.

Use AsyncStorage only for temporary POC persistence such as auth session and registration draft.

Document/photo selection can use real local device pickers, but upload/verification remains mocked.

Mock OTP should accept `123456`.

Mock payment should simulate processing and return a deterministic payment ID.

Live results are read-only. Simulate updates through a results provider. Do not implement tennis scoring logic.

## Design
The app should feel like a polished premium international sports event app:
- clean light backgrounds
- deep blue primary brand family
- modern cards
- strong hierarchy
- event imagery where useful
- clear status chips
- registration progress
- large touch targets
- no giant all-in-one forms
- one logical task per registration step

Follow the previously approved screen direction documented in `docs/SCREEN_FLOW.md` and `docs/DESIGN_SYSTEM.md`.

## Execution
Do NOT implement all 18 screens at once.

First:
1. inspect the repository
2. propose the exact folder structure and dependency additions
3. bootstrap the app and architecture
4. create design tokens + essential reusable UI primitives
5. create domain types, repository contracts, mock fixtures, and mock repositories
6. create navigation skeleton
7. stop and summarize what is ready

Do not start A01–A18 screen implementation until the foundation is clean.

After foundation approval, implement in batches:
- Batch 1: A01–A06
- Batch 2: A07–A12
- Batch 3: A13–A15
- Batch 4: A16–A18
- Final: polish and consistency

At every stage:
- preserve strict TypeScript
- avoid `any`
- run checks
- fix navigation/runtime issues
- reuse components
- keep mock data separate from UI
- do not over-engineer

Start now by reading the instruction files and presenting the implementation plan and proposed repository structure before making major code changes.


## POC development strategy: Expo Web first

For speed, **develop and review the POC primarily through Expo Web in the browser first**.

This does NOT mean building a separate React web app.

We still want:
**React Native + Expo as the single source codebase.**

Use this workflow:

`React Native Expo code -> Expo Web for rapid iteration -> Android/iOS compatibility pass -> same project continues toward production`

Important rules:
- keep every screen React Native compatible
- do not use DOM-only components or web-only screen implementations
- do not create a separate Vite/React version
- avoid native-only setup unless necessary for the POC
- camera, Wallet, push notifications, real payment sheets, biometrics, deep links, and similar integrations may be mocked/simplified initially
- build and visually approve each screen batch on Expo Web first
- after each major batch, run a focused Android/iOS compatibility pass
- choose cross-platform packages over native-only packages when both can satisfy the POC

The goal is to get **React-like browser iteration speed without sacrificing the mobile codebase**.
