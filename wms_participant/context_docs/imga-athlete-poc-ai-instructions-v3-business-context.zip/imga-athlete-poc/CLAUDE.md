# CLAUDE.md

Read `AGENTS.md` first and treat it as the primary engineering instruction file.

Before product/domain work, also read `docs/BUSINESS_CONTEXT.md` so you understand the wider IMGA business model and the boundary between the Athlete POC and the future Admin/GMS ecosystem.

## Working mode
You are implementing a fast but reusable React Native Expo POC for the IMGA Athlete Mobile experience.

Before changing code:
1. Inspect the current repository.
2. Read the relevant files under `/docs`.
3. State the smallest implementation plan.
4. Reuse existing components and patterns before adding new ones.
5. Keep mock data behind repositories/services.

## Non-negotiable
- Do not hardcode mock entities inside screens if they belong in fixtures.
- Do not let UI import fixture JSON directly.
- Do not introduce a backend unless explicitly requested.
- Do not introduce a real payment or OTP provider.
- Do not build an actual scoring engine.
- Do not replace the documented screen flow with your own interpretation.
- Do not create unnecessary libraries or architectural layers.
- Do not remove type safety to move faster.

## Preferred task size
Work feature-by-feature:
- auth
- events
- registration
- partner finder
- payment
- registration status
- accreditation
- GamesHub
- live results

For each feature:
- domain types
- mock repository implementation
- feature hooks
- screen(s)
- reusable components
- state handling

## Validation
After meaningful changes:
- run TypeScript checks
- run lint if configured
- fix runtime/navigation errors
- verify the main path still works

## Main demo path
Login → OTP → Events → Event Detail → Choose Sport → Registration Overview → Personal Profile → Sport & Category → Eligibility & Documents → Accreditation Photo → Partner/Team → Partner Finder → Review + T&C → Payment → Registration Status → Digital Accreditation → GamesHub → Live Match/Result.


## Web-first implementation workflow
Optimize implementation for **Expo Web first** so screens can be reviewed rapidly in a browser.

However, this is still a React Native mobile codebase:
- keep components React Native compatible
- avoid DOM-specific screen implementations
- avoid separate web-only screen trees
- mock native-only integrations during POC when practical
- validate Android/iOS after each screen batch rather than during every small visual iteration

When choosing between two equally good approaches, prefer the one that gives a fast Expo Web feedback loop without reducing later Android/iOS reuse.
